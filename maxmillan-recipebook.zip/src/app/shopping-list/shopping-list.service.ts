import { IngredientInterface } from '../shared/ingredient.model';
import { Subject } from 'rxjs/Subject';
/* we use Subject interface for cross-component communication. Using subject, we pass value from one component and receive the same value in another component. We use next method to pass the value and since it returns observable, we use subscribe method to receive the same value in another component */

export class ShoppingListService {
  ingredientsChanged = new Subject<IngredientInterface[]>();
  startedEditing = new Subject<number>();

  private ingredients: IngredientInterface[] = [
    new IngredientInterface('Apple', 5),
    new IngredientInterface('Tomatoes', 10)
  ];

  getIngredients() {
    return this.ingredients;
  }

  getIngredient(index: number) {
    return this.ingredients[index];
  }

  addIngredient(ingredient: IngredientInterface) {
    this.ingredients.push(ingredient);
    this.ingredientsChanged.next(this.ingredients.slice());
    /* we are passing newly created ingredients array..Since slice method has no arguments, it will pass all the array items */
  }
  
  addIngredients(ingredients: IngredientInterface[]) {
    console.log("before push" ,this.ingredients);
    this.ingredients.push(...ingredients);  
    // ES6 spread operator we are using; "...ingredients" Since ingredients argument is an array and if it is sending multiple array elements then push those elements below each other; below syntax also we can use to achieve the same output

    //** this.ingredients.push(ingredients[0], ingredients[1]);
    // this will output same, but it looks static becuase we are using index nos. here

    this.ingredientsChanged.next(this.ingredients.slice());
    /* we are passing newly created ingredients array */
    console.log("after push", this.ingredients);
  }

  updateIngredient(index: number, newIngredient: IngredientInterface) {
    this.ingredients[index] = newIngredient;
    this.ingredientsChanged.next(this.ingredients.slice());
  }

  deleteIngredient(index) {
    this.ingredients.splice(index,1);
    this.ingredientsChanged.next(this.ingredients.slice());
  }
}