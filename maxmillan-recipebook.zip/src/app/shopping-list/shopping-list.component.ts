import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import { IngredientInterface } from './../shared/ingredient.model';
import { ShoppingListService } from './shopping-list.service';

@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit, OnDestroy {
  ingredients: IngredientInterface[];
  private subscription: Subscription;
  
  constructor( private slService: ShoppingListService ) { }

  ngOnInit() {
    this.ingredients = this.slService.getIngredients();
    this.subscription = this.slService.ingredientsChanged.subscribe(
      (ingredients: IngredientInterface[])  => {
      this.ingredients = ingredients
    }
    )
  }

  onEditItem(index: number) {
    this.slService.startedEditing.next(index);
    /* next method is used to pass/emit any value to another component. Here we are passing index number of recipe to another component. and to receive this value in another component, we will have to subscribe to this subject. */
  }

  // prevent memore leak
    ngOnDestroy() {
    this.subscription.unsubscribe();
   }
}