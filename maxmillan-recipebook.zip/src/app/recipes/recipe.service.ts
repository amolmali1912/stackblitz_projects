import { Injectable } from '@angular/core';  
import { Subject } from 'rxjs/Subject';

import { RecipeInterface } from './recipe.model';
import { IngredientInterface } from '../shared/ingredient.model'
import { ShoppingListService } from '../shopping-list/shopping-list.service'

@Injectable()
/* Remember if you plan injecting a service into a service, we need Injectable decorator. Here we are injecting ShoppingListService service. No need to pass anything to injectable decorator, just import the service at top and then inject it into a constructor.  */
export class RecipeService {
  recipesChanged = new Subject<RecipeInterface[]>();

  private  recipes: RecipeInterface[] = [
    new RecipeInterface(
      'Tasty Schnitzel', 
      'Tasty Schnitzel - Just Awesome!', 'https://upload.wikimedia.org/wikipedia/commons/7/72/Schnitzel.JPG',
       [
        new IngredientInterface('Meat', 1),
        new IngredientInterface('French Fries', 20),
      ]
      ),
    new RecipeInterface(
      'Big Fat Burger', 
      'What else you need to say?', 
      'https://upload.wikimedia.org/wikipedia/commons/b/be/Burger_King_Angus_Bacon_%26_Cheese_Steak_Burger.jpg',
      [
        new IngredientInterface('Buns', 2),
        new IngredientInterface('Meat', 1),
      ]
      )
  ];

  constructor(private slService: ShoppingListService){
  }

  getRecipes() {
    return this.recipes.slice();
  }

   getRecipe(index: number) {
    return this.recipes[index];
  }

  addIngredientsToShoppingList(ingredients: IngredientInterface[]){
      this.slService.addIngredients(ingredients);
  }

  addRecipe(recipe: RecipeInterface) {
      this.recipes.push(recipe);
      this.recipesChanged.next(this.recipes.slice())
  }

  updateRecipe(index:number, newRecipe: RecipeInterface) {
     this.recipes[index] = newRecipe;
     this.recipesChanged.next(this.recipes.slice())
  }

  deleteRecipe(index: number){
    this.recipes.splice(index, 1);
    this.recipesChanged.next(this.recipes.slice())
  }

  setRecipes(recipes: RecipeInterface[]) {
    this.recipes = recipes;
    this.recipesChanged.next(this.recipes.slice());
  }


}