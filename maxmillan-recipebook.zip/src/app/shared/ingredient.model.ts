export class IngredientInterface {
  constructor(public name: string, public amount: number) {
  }
}