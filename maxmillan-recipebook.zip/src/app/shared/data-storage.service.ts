import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 

import { RecipeService } from '../recipes/recipe.service'; 
import { RecipeInterface } from '../recipes/recipe.model'; 


@Injectable()
export class DataStorageService {
  constructor(private http: HttpClient, private recipeService: RecipeService) {}

  storeRecipes() {
    // this will store your recipes to server..
    return this.http.put('https://ng-recipe-book-1f1ec.firebaseio.com/recipe.json', this.recipeService.getRecipes())
  }
  
  // fetching recipes from server: here we are retriving data from server..
  getRecipes() {
    return this.http.get('https://ng-recipe-book-1f1ec.firebaseio.com/recipe.json')
      .subscribe(
        (response) => {
          console.log("response is", response); // it will display data stored on server..
          const recipes: any  = response;
          this.recipeService.setRecipes(recipes);
        }
      )
  }


} 