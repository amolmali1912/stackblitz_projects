/* firebase path is as below to check firebase database..  */
/* https://console.firebase.google.com/project/udemy-ng-http-38db9/database/udemy-ng-http-38db9/data
*/

import { Component } from '@angular/core';

import { ServerService } from './server.service';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  servers = [
    {
      name: 'Testserver',
      capacity: 10,
      id: this.generateId()
    },
    {
      name: 'Liveserver',
      capacity: 100,
      id: this.generateId()
    }
  ];
  constructor(private serverService: ServerService) {

  }
  onAddServer(name: string) {
    this.servers.push({
      name: name,
      capacity: 50,
      id: this.generateId()
    });
  }
  private generateId() {
    return Math.round(Math.random() * 10000);
  }

  onSave() {
    this.serverService.storeServers(this.servers).subscribe(
      (response) => { console.log(response) },
      (error) => { console.log(error) },
    );
    /* we are calling storeServers method by pasing this.servers array and at the same time we are subscribing to the observable, which gets returned by storeServers method. since storeServers contains http.post method, when we subscribe to storeServers method, Two things will happen; 
        a) it will send http request to server and then
        b) it will get response from server */
  }


  onGet() {
    this.serverService.getServers().subscribe(
      (servers: any[]) => { 
          /* const data = response.json(); console.log(data);  */

          /* response.json() is no longer required in angular 4 and 4+ versions. HttpClient.get() applies response.json() **automatically. You no longer need to call this function yourself. */

          console.log(servers);
       },
      (error) => { console.log(error) },
    )
  }

}
