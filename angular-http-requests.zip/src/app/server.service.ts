/* firebase path is as below to check firebase database..  */
/* https://console.firebase.google.com/project/udemy-ng-http-38db9/database/udemy-ng-http-38db9/data
*/

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';  
//For Angular 4 and above versions, use 'HttpClient' instead of 'Http'.
// import { Http } from '@angular/http'; /* angular2 'http' Deprecated now */
import 'rxjs/Rx';  // to use observable's map operator, import this statement..

@Injectable()  // Since we are injecting angular's inbuilt HttpClient service here, we need Injectable decorator. Remember if you plan injecting a service into a service, we need Injectable. No need to pass anything to injectable decorator, just import the service whichever required on top and then inject it into a constructor.

export class ServerService {
  constructor(private http: HttpClient) {}

  /* storeServers method: make http request and then store data to server/backend */
  storeServers(servers: any[]) {
      const headers = new HttpHeaders({ 'Content-Type': 'application/json' })
      /* const headers = new Headers({ 'Content-Type': 'application/json' })  /* angular2 syntax */
      
      /* In some cases, we may need to send specific headers alongwith our http request. Sending specific headers is totally depend upon the backend we are using. By using HttpHeaders we can send our own HttpHeaders. */
      
      /* To check HttpHeaders/Request Headers, go to network tab, and then select our json file i.e. data.json, then click on Headers, then request-headers then check 'Content-Type'. If we set Content-Type : 'application/amol', you will see the same there. application/json is default header so whether we specify here or not, it will exist in network tab all the time. Just note, If we want our own headers to be set, just use 'HttpHeaders'. and then pass those headers in object format, as an third argument in post/get method.

      // return this.http.post('https://udemy-ng-http-38db9.firebaseio.com/data.json', 
      //     servers, 
      //   { headers: headers });
      /* 1) first argument will be the URL to which we want to send the http request, backend URL where we want to store the data. and second argument will be, the data we are sending to the URL while we make http request.
      
      2) post method of http service, just creates an observable. We will have to subscribe to this observable in order to get the response. And note, **until we subscribe, no any http request will get send to the server**. This simply means, angular telling us like, if you want response only in that case I will send http request to server in order to get response. And if you do not want response, then what's the point in sending the request? So I will not send the request.
      
      3) In the URL, we are setting end-point by specifying "data.json". This simply means, it will create json representation in firebase i.e. 'data'. and our data will be stored in that data object. 
      
      4) ****Remember, post method append/add data to server. So whenever we call post, everytime our data will get added to server.

      */

      /* put():
      put method is used to replace old data with new data in database. This simply means, old data will get removed first and new data which we are passing, will get added to database. This is exactly opposite with post method, Post method appends new data to old data. Post does not remove anything from database. 
      
      Usually we use put method, to update something in database. Updating data simply means we are overriding old data with new one. For Ex. updating a customer by id. Everything is same, but id needs to be updated.  */

       return this.http.put('https://udemy-ng-http-38db9.firebaseio.com/data.json', 
          servers, 
        { headers: headers });

  }

  /* getServers method: pass http request to server then get data from server */
  getServers() {
    return this.http.get('https://udemy-ng-http-38db9.firebaseio.com/data.json')
      .map(
        (response) => { 
            return response; 
            
         }
        )
  }



}