import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';

import { HelloComponent } from './hello.component';
import { TestComponent } from './test.component';
import { EmployeeService } from './employee.service';
import { EmployeeListComponent } from './employee-list.component';
import { EmployeeDetailComponent } from './employee-detail.component';
import { TestDirective } from './test.directive';
import { AppRoutingModule } from "./app-routing/app-routing.module";
import { View1Component } from './view1/view1.component';
import { View2Component } from './view2/view2.component'


@NgModule({
  imports: [BrowserModule, FormsModule, HttpClientModule, AppRoutingModule],
  declarations: [AppComponent, HelloComponent, TestComponent, EmployeeListComponent, EmployeeDetailComponent, TestDirective, View1Component, View2Component],
  bootstrap: [AppComponent],
  providers: [EmployeeService]
})
export class AppModule { }
