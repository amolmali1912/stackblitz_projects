import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { IEmployee } from './employee';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { Observable } from "rxjs";


/**** No need to import Observable like we do in angular5 ****/

@Injectable()
export class EmployeeService {
  private _url: string = "/assets/data/employees.json";

   constructor(private http: HttpClient) { }

  getEmployees()  {
    // return [
    //   {id: 1, "name" : "Andrew", "age": 30},
    //   {id: 2, "name" : "Brandon", "age": 25},
    //   {id: 3, "name" : "Christina", "age": 26},
    //   {id: 4, "name" : "Elena", "age": 32}
    // ]

    return this.http.get<IEmployee[]>(this._url);
  }


  
}
