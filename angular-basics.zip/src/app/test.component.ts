
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
            <p>Instructor is {{instructor}}</p>
            <h4>Page URL is: {{Url}}</h4>
            <input type="text" [id]="testId" placeholder="Property Binding" />
            <br/> <br/>
            <input type="text" class="{{testClass}}" placeholder="Property Binding" />
            <h2 [class.text-success]="trueClass">class-Binding here</h2>
            <h2 [ngClass]="attachClasses">ngClass here</h2>
            <h2 [style.color]="orangeColor">simple style binding here</h2>
            <h2 [style.color]="'orange'">Another simple style binding here</h2>
            <h2 [style.color]="hasError ? 'red' : 'green' ">Conditional style binding here</h2>
            <h2 [ngStyle]="multiStyles">ngStyle here</h2>
            <br>
            <h4>Template reference variable with event Binding:<h4>
            <button (click)="clickEvent(btnRef)" #btnRef id="btnID">Click Me</button>
            <br/> <br/>
            <input type="text" [(ngModel)]="TwoWayVar"/> 
            <br/><br/>
            {{TwoWayVar}}
            <br><br>
            <h2>ngIf example:</h2>
            <div *ngIf="false">This is hidden div</div>
            <div *ngIf="true">This is visible div</div>
            <br>
            <div *ngIf="false; then thenBlock; else elseBlock"></div>

            <ng-template #thenBlock>
            <div>Then Block Executed</div>
            </ng-template>

            <ng-template #elseBlock>
            <div>Else Block Executed</div>
            </ng-template>
            
            <br><br>

             <h2>ngSwitch example:</h2>
            <div [ngSwitch]="myColor">
              <div *ngSwitchCase="'red'">RED Color</div>
              <div *ngSwitchCase="'yellow'" [style.background-color]="myColor">Yellow Color</div>
              <div *ngSwitchCase="'green'">Green Color</div>
            </div>

            <h2>ngFor with special variables:</h2>
            <div *ngFor="let c of colors; index as i; even as e; odd as o, first as f, last as l">
              <h4>{{ c }}, Index: {{ i }},  Even: {{e}}, Odd: {{o}}, First: {{f}}, Last: {{l}} </h4>
            </div>
            <br>

            <h2>Angular Pipes</h2>
            <p>{{ greet }}<p>
            <p>{{ greet | lowercase }}<p>
            <p>{{ greet | uppercase }}<p>
            <p>{{ greet | titlecase }}<p>
            <p>{{ greet | slice:3 }}<p>
            <!-- Slice first argument is start index -->
            <p>{{ greet | slice:3:5 }}<p>
            <!-- Slice second argument is end index. End index character is excluded -->
             <h2>JSON Pipe:</h2>
            <p>{{ person | json }}<p>

             <h2>Number Pipe:</h2>
            <p>{{ 5.678 | number }}<p>
            <p>{{ 5.678 | number: '1.2-3' }}<p>
            <p>{{ 5.678 | number: '3.4-5' }}<p>
            <p>{{ 5.678 | number: '3.1-2' }}<p>
            <p>{{ 005.678 | number: '1.2-3' }}<p>
            <p>{{ 005.678 | number: '3.2-3' }}<p>

            <h2>Percent Pipe:</h2>
            <p>{{ 0.25 | percent  }}<p>
            <p>{{ 1 | percent  }}<p>

             <h2>Currency Pipe:</h2>
            <p>{{ 25 | currency  }}<p>
            <p>{{ 25 | currency : "EUR" : 'code'  }}<p>

            <h2>Date Pipe:</h2>
            <p>{{ date  }} <p>
            <p>{{ date | date : 'short' }} <p>
            <p>{{ date | date : 'shortDate' }} <p>
            <p>{{ date | date : 'long' }} <p>
            <p>{{ date | date : 'longDate' }} <p>
            <p>{{ date | date : 'shortTime' }} <p>
            
            <br>
             <h2>Component Interaction: </h2>
             <h4>Parent To child Interaction: Below Value comes from Parent</h4>
             <div class="text-success">{{parentData}}</div>
             <h4>Child to Parent interaction:</h4>
             <button (click)="fireEvent()" >Send Event</button>

  `,
  styles: [
    `
    .text-success {
      color: green;
    }
     .text-danger {
      color: red;
    }
     .text-italic {
      font-style: italic;
    }
    `
  ]
})

export class TestComponent implements OnInit {
  public instructor = "Vishwas";
  public Url = location.href;
  public testId = 'input-id';
  public testClass = 'input-class';
  public trueClass = true;
  public attachClasses = {
    "text-success": this.trueClass,
    "text-danger": !this.trueClass,
    "text-italic": this.trueClass,
  }
  public orangeColor = 'orange';
  public hasError = true;
  public multiStyles = {
    color: 'yellow',
    backgroundColor: "green"
  }
  public myColor = "yellow";
  public colors = ["Red", "Green", "Blue", "Purple"]
  @Input() public parentData;
  // @Input('parentData') public myVar;
  public childVar = "This is child property"
  @Output() public childEvent = new EventEmitter();
  public greet = 'Hello world';
  person = {
    "firstName" : 'John',
    "lastName" : "Doe"
  }
  public date = new Date();

  constructor() { }

  ngOnInit() { }

  clickEvent(ele) {
    var msg = "Button Texts: " + ele.innerText + "\nTexts length: " + ele.innerText.length;
    alert(msg)
  }

  fireEvent() {
    this.childEvent.emit(this.childVar)
  }

}