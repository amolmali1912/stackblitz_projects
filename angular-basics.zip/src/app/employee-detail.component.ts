import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-employee-detail',
  template: `
    <h2>Employee Detail component</h2>
    <ol *ngFor="let employee of employees">
      <li [style.list-style-type]="'square'">{{employee.name}}</li>
    </ol>
  `,
  styles: []
})
export class EmployeeDetailComponent implements OnInit {
  public employees = [];

  constructor(private _employeeService : EmployeeService ) { }

  ngOnInit() {
    this._employeeService.getEmployees()
    .subscribe( data => this.employees = data );
  }

}