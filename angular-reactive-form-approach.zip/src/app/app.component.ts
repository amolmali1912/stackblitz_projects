import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
// import { Observable } from 'rxjs';  /* this is acceptable in angular7 */
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit  {
  genders = ['male', 'female'];
  signupForm : FormGroup;  /* signupForm is a property that holds form, holds form related all data  */
  forbiddenUserNames = ['Chris', 'Anna'];

  ngOnInit() {
  /* 
    1) creating new form in typescript: we are creating form named signupForm using 3 controls as below:
    FormControl takes 3 arguments, first is initial value to be displayed in input field, if we do not want to assign any value bydefault just assign 'null', second argument will be either inbuilt validator or our custom validator, validator can be single or multiple in numbers, if multiple validators are there, put them into an array of validators. and third argument will be async code/async validator. It contains single or multiple custom async Validators. We need async code because often we receive response from webserver, we don't receive webserver response instantly, it takes some time. in this scenario we need async code that wait for some time & then come back to us with response to validate whether validation error is there or not..

    2) Grouping of controls: If you want grouping of your controls, you will need nested FormGroup. Inside Main FormGroup, we will need another FormGroup that will hold multiple controls as per your requirement. Like below, inside main FormGroup, we have userData FormGroup that contains 'username' and 'email' controls. Remember, If grouping of controls there, two things should be there in template. a) Take a parent component that contains those controls; and assign formGroupName as we specified in typescript and b) if we are adding validations,add path alongwith controlName inside get method like formGroupName.controlName

    3) FormArray holds an array of controls..

    4) Since every control need unique name, when we create form control dynamically using FormArray, assign index as name. We can retrieve indexes using ngFor directive
*/
    this.signupForm = new FormGroup({
      'userData': new FormGroup({
        'username': new FormControl(null, [Validators.required, this.forbiddenNames.bind(this)]),
        'email': new FormControl(null, [Validators.required, Validators.email], this.forbiddenEmails),
      }),
      'gender': new FormControl('male'),
      'hobbies': new FormArray([]),
    })
    /* 
      1) There are two observables available with Form, i.e. valueChanges and statusChanges;
      2) valueChanges and statusChanges observable can be accessed inside ngOnInit hook. if you place it on another place, in another method, you will get error.  */


/**** valueChanges observable: 
        1) valueChanges fired whenever we change value of *any* control.  ***/
        
        /************************ valueChanges Example:  ****************************/

    this.signupForm.valueChanges.subscribe((value) => {
    console.log(value);
  })


 /************************ statusChanges Example:  ****************************/
 /****  1) statusChanges fired whenever any change occurs in form **status**. 
        2) form status can be valid, invalid or pending. 
        3) We see form status pending, only if we are using async validators as a third argument of FormControl.   ****/
    
    this.signupForm.statusChanges.subscribe((status) => {
    console.log(status);
  })

/************************ setting form values:  ****************************/  
/* we can set form values using setValue and patchValue methods. Both method takes an object with control names as keys and sets those control values accordingly. 
1) setValue method changes all the control values. This method is useful only when we need to set all control values whereas 
2) patchValue changes your form partially by changing few controls or just one control. We need patchValue method when we dont want to change all the control values in one go. */

    this.signupForm.setValue({
      'userData': {
        'username': 'Max',
        'email': 'max@test.com'
      },
      'gender': 'male',
      'hobbies': []
    })

      this.signupForm.patchValue({
      'userData': {
        'username': 'Brad'
      }
    })

  }

  onSubmit() {
    console.log(this.signupForm)
  }

  /**** Custom validator:
   1) forbiddenNames is custom validator here, custom validator is just a function which gets executed by angular automatically when it checks the validity of the form control 
   
   2) this method returns key value pair. key definition is inside square brackets. key should be string and its value would be boolean value. s stands for key and key type will be string 
  
   3) We can assign any name instead of nameIsForbidden, it is just to hold key we receive  
   
   */
   
  forbiddenNames(control: FormControl): {[s: string]: boolean} {
    if(this.forbiddenUserNames.indexOf(control.value) !== -1 )  {
      return { 'nameIsForbidden': true }; 
    }
    else {
      return null;  
      /* return null or return nothing is acceptable. Note, do not return "nameIsForbidden': false"; */
    }
  }


 /**** async validator:  **/
  forbiddenEmails(control: FormControl): Promise<any> | Observable<any> {
    const promise = new Promise<any>((resolve, reject) => {
      setTimeout(() => {
        if(control.value === 'test@test.com'){
          resolve({ 'emailIsForbidden': true})
        } else resolve(null)
      },1500)
    })
    return promise;
  }


  onAddHobby() {
    /* push this control to hobbies array */
    const control = new FormControl(null, Validators.required);  
    /* hobbies is <Formarray> type, so assign type FormArray to get method as below  */
   (<FormArray>this.signupForm.get('hobbies')).push(control);
  }
  
}
