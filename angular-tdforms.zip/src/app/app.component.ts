import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  @ViewChild('f') signupForm: NgForm;  /* Accessing form element using ViewChild, assign type NgForm */
  defaultQuestion = 'teacher';
  answer = "";
  genders = ["male", "female"];
  user  = {
    username: '',
    email: '',
    secretQuestion: '',
    answer: '',
    gender: ''
  };
  submitted = false;

  suggestedUserName() {
    const suggestedName = 'Superman';

    /* setValue and patchValue methods are used to change form control values dynamically. 
    The difference is, setValue changes your form **completely** by changing all the control values. setValue does not change single control's value.  It takes all controls alongwith initial values to be assigned at the time of calling setValue method.;
    Whereas patchValue changes your form **partially**.  It can change only one value if it is required. Hence patchvalue is more useful method if you want to change single control's value */

    //  this.signupForm.setValue({  
    //   userData: {      // username and email inside userData ngModelGroup
    //     username: suggestedName,
    //     email: ''
    //   },
    //   secret: 'pet',
    //   questionAnswer: '',
    //   gender : 'male'
    // })


  /* Note,when we use setValue method, we don't need to use form after formName like we use above; but if we use patchValue method, we need to use form after formName as below:  */
    this.signupForm.form.patchValue({
      userData: {
        username: suggestedName
      }
    })
  }

  onSubmit(form: NgForm) {
       console.log(this.signupForm) 
      /* it returns NgForm Object, Angular create this object automatically, in this object we will get all the form  related stuff like value typed in form controls/inputs, control names, their states etc. */

      this.submitted = true
      this.user.username = this.signupForm.value.userData.username;
      this.user.email = this.signupForm.value.userData.email;
      this.user.secretQuestion = this.signupForm.value.secret;
      this.user.answer = this.signupForm.value.questionAnswer;
      this.user.gender = this.signupForm.value.gender;
      /* this.signupForm points to NgForm here, that holds all form data, so when we fetch form data, "this.signupForm.value.controlName" will be the path to fetch data, if ngModelGroup is there to grouping controls, after value we will have to put that ngModelGroup and then control name.  */


      this.signupForm.reset();   /* reset() will clear all the field values after form submission here,
       and if you want to reset all the fields on click of reset button, use setValue method to do so */
  }
}
